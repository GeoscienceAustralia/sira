:orphan:

Acknowledgements
=================

Mark Edwards: for the vision behind this simulation tool.

Martin Wehner: for initial planning and design of the predecessor to this code.

Ammar Ahmed: for identifying requirements for improving capabilities in the original software.

Maruf Rahman: for revision of the 'facility model', input data preservation, and small bug fixes.

Hyeuk Ryu: for identifying bugs, testing, and improvement suggestions.

Sudipta Basak: for help with code cleanup, setting up some tests, and the move to OOD.