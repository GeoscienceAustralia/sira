.. _Geoscience Australia: http://www.ga.gov.au/

.. |nbsp| unicode:: 0xA0 
   :trim:

.. |eg| replace:: e.g.,

.. |etal| replace:: et al.

.. |ie| replace:: i.e.,

.. |dash| unicode:: 0x2014
   :trim:

.. |br| raw:: html

   <br />

.. |copyright| unicode:: 0xA9

.. |LE| unicode:: 0x2264

.. |GE| unicode:: 0x2265

.. |LT| unicode:: 0x003C

.. |GT| unicode:: 0x003E

.. |BlkSquare| unicode:: 0x25A0 .. Black square

.. |BlkSquareSml| unicode:: 0x25AA .. Black square small

.. |WhtSquare| unicode:: 0x25A1 .. White square

.. |BlkCircleSmall| unicode:: 0x2022 .. Black cirle small

.. |BlkCircleMed| unicode:: 0x25CF .. Black cirle medium

.. |BlkCircleLarge| unicode:: 0x2B24 .. Black cirle large

.. |rightdoubleangle| unicode:: 0x00BB .. Right-pointing double angle quotation mark

.. |rightarrow| replace:: :math:`\rightarrow`

.. |doublerightarrow| replace:: :math:`\Rightarrow`

.. === GREEK SMALL LETTERS ====================================================

.. |alpha| unicode:: 0x03B1

.. |beta| unicode:: 0x03B2

.. |gamma| unicode:: 0x03B3

.. |delta| unicode:: 0x03B4

.. |epsilon| unicode:: 0x03B5

.. |zeta| unicode:: 0x03B6

.. |eta| unicode:: 0x03B7

.. |theta| unicode:: 0x03B8

.. |iota| unicode:: 0x03B9

.. |kappa| unicode:: 0x03BA

.. |lambda| unicode:: 0x03BB

.. |mu| unicode:: 0x03BC

.. |nu| unicode:: 0x03BD

.. |xi| unicode:: 0x03BE

.. |omicron| unicode:: 0x03BF

.. |pi| unicode:: 0x03C0

.. |rho| unicode:: 0x03C1

.. |finalsigma| unicode:: 0x03C2

.. |sigma| unicode:: 0x03C3

.. |tau| unicode:: 0x03C4

.. |upsilon| unicode:: 0x03C5

.. |phi| unicode:: 0x03C6

.. |chi| unicode:: 0x03C7

.. |psi| unicode:: 0x03C8

.. |omega| unicode:: 0x03C9

.. === GREEK CAPITAL LETTERS ==================================================

.. |deltaCap| unicode:: 0x0394
