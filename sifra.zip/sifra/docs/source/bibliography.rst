:orphan:

.. only:: html

    References
    ==========

.. bibliography:: _static/files/refs.bib
   :all:
   :style: plain
