
class Location(object):
    def __init__(self, lat_p=0.0, lon_p=0.0, height_p=0.0):
        self.lat = lat_p
        self.lon = lon_p
        self.height = height_p
