import numpy as np

class Scenario():
    """
    Defines the scenario for hazard impact modelling
    """

    def __init__(self, configuration):

        """Set up parameters for simulating hazard impact"""
        self.num_hazard_pts = \
            int(round((configuration.haz_param_max - configuration.haz_param_min) /
                      float(configuration.haz_param_step) + 1))

        self.hazard_intensity_vals = \
            np.linspace(configuration.haz_param_min, configuration.haz_param_max,
                        num=self.num_hazard_pts)
        self.hazard_intensity_str = \
            [('%0.3f' % np.float(x)) for x in self.hazard_intensity_vals]

        # Set up parameters for simulating recovery from hazard impact
        self.restoration_time_range, self.time_step = np.linspace(
            0, configuration.restore_time_max, num=configuration.restore_time_max + 1,
            endpoint=True, retstep=True)

        self.num_time_steps = len(self.restoration_time_range)

        self.restoration_chkpoints, self.restoration_pct_steps = \
            np.linspace(0.0, 1.0, num=configuration.restore_pct_chkpoints, retstep=True)