import unittest as ut

config_file = '/opt/project/tests/test_scenario_ps_coal.conf'


class TestIngestResponseModel(ut.TestCase):

    def test_config_file_exist(self):

    def test_required_fields_inconfig_file_exist(self):

    def test_=
    def test_file_exist(self):

    def test_number_of_reqquired_sheets(self):

    def test_required_headings_exist_in_component_list_sheet(self):

    def test_format_of_data_in_heading_component_id(self):


    def test_component_list_component_id(self):
        #read excel file

    def test_hazard_raster(self):
        test_conf = '../tests/test_scenario_ps_coal.conf'
        scenario = Scenario(test_conf)

        test_raster = Dataset("test_raster.nc", "w", format="NETCDF4")
        lats = np.arange(-90, 91, 1.0)
        lons = np.arange(-180, 180, 1.0)
        lat = test_raster.createDimension("lat", len(lats))
        lon = test_raster.createDimension("lon", len(lons))
        latitudes = test_raster.createVariable("lat", "f4", ("lat",))
        longitudes = test_raster.createVariable("lon", "f4", ("lon",))
        pga_factor = test_raster.createVariable("pga_factor", "f4", ("lat", "lon",), fill_value=False)
        test_raster.description = "unit test raster"
        test_raster.source = "netCDF4 python module tutorial"
        latitudes.units = "degrees north"
        longitudes.units = "degrees east"
        latitudes[:] = lats
        longitudes[:] = lons
        pga_factor[:, :] = np.ones((len(lats), len(lons)))

        scenario.level_factor_raster = test_raster

        hazard_levels = HazardLevels(scenario)

        hazard_levels = list(hazard_levels.hazard_range())

        self.assertTrue(len(hazard_levels) > 4)

        location = Location(-28.0, 135.0, 0)

        for hazard_level in hazard_levels:
            self.assertTrue(hazard_level.determine_intensity_at(location) > 0)



if __name__ == '__main__':
    ut.main()
